
/**
 *
 * Support package for declarative AOP configuration,
 * with XML schema being the primary configuration format.
 *
 */
package org.springframework.aop.config;

